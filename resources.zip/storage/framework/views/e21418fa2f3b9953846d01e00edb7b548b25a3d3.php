<?php if(Session::has('success')): ?>
   <div class="alert alert-success">
     <strong>Success:</strong> <?php echo e(Session::get('success')); ?>

   </div>
<?php endif; ?>
<?php if(Session::has('consuccess')): ?>
   <div class="alert alert-success ">
     <strong>Success:</strong> <?php echo e(Session::get('consuccess')); ?>

   </div>
<?php endif; ?>
<?php if(Session::has('loginsuccess')): ?>
   <div class="alert alert-success">
     <?php echo e(Session::get('loginsuccess')); ?>

   </div>
<?php endif; ?>
<?php if(Session::has('loginerror')): ?>
   <div class="alert alert-danger">
      <strong>Error:</strong> <?php echo e(Session::get('loginerror')); ?>


   </div>
<?php endif; ?>
<?php if(Session::has('profileerror')): ?>
   <div class="alert alert-danger" style="width: 400px;">
      <strong>Error:</strong> <?php echo e(Session::get('profileerror')); ?>


   </div>
<?php endif; ?>
<?php if(Session::has('adsuccess')): ?>
   <div class="alert alert-success" style="width: 400px;">
     <strong>Success:</strong> <?php echo e(Session::get('adsuccess')); ?>

   </div>
<?php endif; ?>
<?php if(count($errors)>0): ?>
  <div class="alert alert-danger" style="max-width: 500px;">
     <strong>Error</strong> 
     <ul>
     	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	 <li><?php echo e($error); ?></li>
     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
  </div>

<?php endif; ?>