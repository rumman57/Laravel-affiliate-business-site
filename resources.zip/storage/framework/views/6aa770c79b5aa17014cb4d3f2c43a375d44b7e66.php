<?php $__env->startSection('title','Products'); ?>
<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User Commission Details
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Users</a></li>
        <li class="active">User Commission Details</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
                <h3>Total Commission : <b><span style="color: green"><?php echo e($total); ?></span></b></h3>
                <h3>Paid Till: <b><span style="color: #0f5a7f"><?php echo e($paid); ?></span></b></h3>
                <h3>Paid Remaining: <b><span style="color: crimson"><?php echo e($remaining); ?></span></b></h3>
            </div><br>

            <div style="margin-left: 20px;">
              <h4 style="color: crimson;">**Note </h4>
              <h5 style="font-size: 17px;">After payment for each user for each product you must submit it  as paid.</h5>
            </div><br>
            <!-- /.box-header -->
            <div class="box-body">
               <div style="overflow-x:auto;">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                 <tr>
                 <th style="text-align: center;" width="10%">Num.</th>
                  <th style="text-align: center;" width="20%">Name</th>
                  <th style="text-align: center;" width="10%">Price</th>
                  <th style="text-align: center;" width="10%">Commision</th>
                  <th style="text-align: center;" width="10%">Revenue By Commision</th>
                  <th style="text-align: center;" width="10%">Date</th>
                  <th style="text-align: center;" width="10%">Status</th>
                  <th style="text-align: center;" width="10%">Submit as Paid</th>
                </tr>
                </thead>
                <tbody>
                <?php $i=0;?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $i++;?>
                <tr style="text-align: center;">
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($product->product_name); ?></td>
                  <td><?php echo e($product->product_price); ?></td>
                  <td><?php echo e($product->product_commission); ?>%</td>
                  <td><?php echo e((($product->product_price * $product->product_commission)/100)); ?></td>  
                  <td><?php echo e(date('M j, Y',strtotime($product->created_at))); ?></td>   
                  <td>
                    <?php if($product->is_paid==1): ?>
                       <button class="btn btn-success">Paid</button>
                    <?php else: ?>
                       <button class="btn btn-info">Not Paid</button>
                    <?php endif; ?> 
                  </td>
                  <td><a href="<?php echo e(route('user.submission.payment',$product->id)); ?>"><button class="btn btn-primary">Submit As Paid</button></a></td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>             
              </table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('myadmin.lib.fortable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('myadmin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>