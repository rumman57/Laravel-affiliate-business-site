<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Availabe For Selling Products
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Sell Products</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
       <form method="POST" action="<?php echo e(route('products.selected')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-md-4 col-xs-12">
              <br><button class="btn btn-success btn-block">Submit Seleted Products</button><br>
          </div>
         
        </div>
        
       <?php $__currentLoopData = $products->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="row">
         <?php $__currentLoopData = $chunkproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-2 col-xs-12" class="text-center">
              <img style="display: block; margin-left: auto;margin-right: auto; " src="<?php echo e($product->image); ?>" height="170" width="170">
            <div class="text-center">
             <h3><?php echo e($product->name); ?></h3>
             <h4>Price: <?php echo e($product->sellprice); ?> Taka</h4>
             <h4>Commission: <?php echo e($product->commision); ?>%</h4>
             <div>
                 <div class="checkbox">
                  <label><input type="checkbox" value="<?php echo e($product->id); ?>" name="check_product[]">SELECT</label>
                </div>
             </div>
           </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('myadmin.lib.adminfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('myadmin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>