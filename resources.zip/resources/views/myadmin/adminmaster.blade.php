@include('myadmin.lib.adminheader')
@include('myadmin.lib.adminsidebar')
@yield('content')
@yield('footer')